<footer><div id="footerFrame">
        <div id="unicorn">
            <h1>UNICORN</h1>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quaerat int ut obcaeca eveniet modi, eum quasi voluptatem natus.</p>
            
            <div id="inputs">
                <input type="email" placeholder="EMAIL" class="emailSubject"><input type="text" placeholder="SUBJECT" class="emailSubject"><input type="text" placeholder="MESSAGE" id="message"></div>

            <div id="buttonFrame"><button>SEND <img src="<?php echo esc_url(get_template_directory_uri()."/Images/arrow.png"); ?>" alt=""></button></div>
            
        </div>
        <div id="linksFrame">
            <div class="links">
                <h2>LINKS</h2>
                <li class="link_items"><a href="#">Home</a></li>
                <li class="link_items"><a href="#">About</a></li>
                <li class="link_items"><a href="#">Services</a></li>
                <li class="link_items"><a href="#">Menu</a></li>
                <li class="link_items"><a href="#">Restaurants</a></li>
                <li class="link_items"><a href="#">Work Hours</a></li>
                <li class="link_items"><a href="#">Call Hours</a></li>
            </div>
            <div class="links">
                <h2>FRIENDS</h2>
                <li class="link_items"><a href="#">Home</a></li>
                <li class="link_items"><a href="#">About</a></li>
                <li class="link_items"><a href="#">Services</a></li>
                <li class="link_items"><a href="#">Menu</a></li>
                <li class="link_items"><a href="#">Restaurants</a></li>
            </div>
            <div class="links">
                <h2>SOCIAL</h2>
                <li class="link_items"><a href="#">Facebook</a></li>
                <li class="link_items"><a href="#">Twitter</a></li>
                <li class="link_items"><a href="#">Github</a></li>
                <li class="link_items"><a href="#">Linkdin</a></li>
                <li class="link_items"><a href="#">Youtube</a></li>
                <li class="link_items"><a href="#">Tiktok</a></li>
                <li class="link_items"><a href="#">Google Plus</a></li>
                <li class="link_items"><a href="#">Others</a></li>
            </div>
        </div>
    </div>

    <hr id="footerLine"><div id="copyrightFrame">
        <div id="copyright">
            <p id="copyText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit.</p>
            <p id="copyYear"><img src="<?php echo esc_url(get_template_directory_uri()."/Images/copyright.png"); ?>" alt="#">2005 Your Awesome Company</p>
        </div>
        <div id="termsFrame">
            <li class="terms"><a href="#">TERMS</a></li>
            <li class="terms"><a href="#">PRIVACY POLICY</a></li>
            <li class="terms"><a href="#">CONTACT</a></li>
            <li class="terms"><a href="#">JOB</a></li>
        </div>
    </div>
</footer><!--                 Footer Start               -->
<script src="script.js"></script><?php wp_footer(); ?> </body></html>