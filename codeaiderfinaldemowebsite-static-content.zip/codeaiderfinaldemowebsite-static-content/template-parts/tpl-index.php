<?php /* Template Name: Template Index 

             
               */ 
               get_header(); ?> <!-- storyteller Portion end --><!-- Who & Why Portion Start --><div id="secondContainer">
        <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="firstIcon"><h2>Who & Why</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates, esse culpa incidunt labore qui quibusdam, vero rerum quae, ex temporibus id quo aperiam reprehenderit velit dolorum eius illum ullam veritatis. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod excepturi quis eaque, id quibusdam doloremque officia vitae. Quidem voluptate et explicabo sapiente libero dolor, magni animi porro maiores, repellat accusamus?</p>
    </div>
    <!-- Who & Why Portion end -->



    <!-- an wow feature Portion Start -->
    <div id="thirdContainer">
        <div id="subContainer">
            <div id="wow">
                <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="secondIcon"><h2 class="feature">An Wow Feature</h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti obcaecati quidem eveniet incidunt? Esse porro nesciunt</p>
            </div>
            <div id="beautiful">
                <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="thirdIcon"><h2 class="feature">An Beautiful Feature</h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti obcaecati quidem eveniet incidunt? Esse porro nesciunt</p>
            </div>
            <div id="amazing">
                <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="fourthIcon"><h2 class="feature">An Amazing Feature</h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti obcaecati quidem eveniet incidunt? Esse porro nesciunt</p>
            </div>
        </div>
    </div>
    <!-- a wow feature Portion end -->



    <!-- feature articles Portion start -->

    <div id="fourthContainer">
        <h2>Featured Articles</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis, incidunt, velit accusantium libero consectetur nihil et eum voluptates veritatis perspiciatis ad maxime voluptatum consequatur dolorum.</p>
    </div>
    <!-- feature articles Portion end -->



    <!-- card slider Portion start -->
    <div id="fifthContainer">
        <div id="subFifth">
            <div id="frame">
                <div id="subFrame">

                    <div id="comic" class="card">
                        <h3 class="topic">1</h3>
                        <p>sdsd</p>
                        <div class="photo">
                            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt=""><p>asdf</p>
                        </div>
                    </div>


                    <div id="lifestyle" class="card">
                        <h3 class="topic">2</h3>
                        <p>asdf</p>
                        <div class="photo">
                            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt=""><p>asdf</p>
                        </div>
                    </div>


                    <div id="travel" class="card">
                        <h3 class="topic">3</h3>
                        <p>asdf</p>
                        <div class="photo">
                            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt=""><p>asdf</p>
                        </div>
                    </div>


                    <div id="something" class="card">
                        <h3 class="topic">4</h3>
                        <p>asdf</p>
                        <div class="photo">
                            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt=""><p>asdf</p>
                        </div>
                    </div>
                    
                    
        
                </div>
            </div>
            <img src="<?php echo esc_url(get_template_directory_uri()."/Images/caret-right.svg"); ?>" alt="#" id="arrow"></div>
    </div>
    <!-- card slider Portion end -->



    <!-- clint portion start -->
    <div id="clients">
        <h2>Clients</h2>
    </div>

    <div id="sixthContainer">
        <div id="subSixth">
            <div id="secondFrame">
                <div id="slider">
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                    <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" class="clientLogo"></div>
                </div>

            </div>
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="slideButton"></div>
    </div>
    <!-- clint portion end -->


    <!-- portfolio portion start -->
    <div id="seventhContainer">
        <h2 id="portfolio">Portfolio & Screenshots</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam autem nostrum repellendus obcaecati consequatur expedita necessitatibus hic tenetur sapiente quam. Eveniet quod neque error corrupti aliquid placeat molestiae.</p>
        <div id="design"></div>
        <div id="subPages">
            <a href="#">Art</a>
            <a href="#">Mystery</a>
            <a href="#">Illusion</a>
            <a href="#">Travel</a>
            <a href="#">Paintings</a>
        </div>
    </div>
    <!-- portfolio portion end -->

    

    <!-- image container portion start -->
    <div id="imageContainer">
        <div id="gallery">
            <div class="subGallery">
    
                <div class="slideImages">
                    <span><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="" class="allImages"></span>
                </div>
    
    
                <div class="slideImages">
                    <span><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="" class="allImages"></span>
                </div>
    
                <div class="slideImages">
                    <span><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="" class="allImages"></span>
                </div>
    
                <div class="slideImages">
                    <span><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="" class="allImages"></span>
                </div>
    
                <div class="slideImages">
                    <span><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="" class="allImages"></span>
                </div>
    
                <div class="slideImages">
                    <span><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="" class="allImages"></span>
                </div>
            </div>
        </div>
        
    </div>
    
    <div id="bottom">
            
    </div>
    <!-- image container portion end -->


    <!-- denis waitley portion start -->
<div id="ninethContainer">
    <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="quoteIcon"><p id="quoteText">Happiness cannot be traveled to, owned, earned, or worn. It is the spiritual experience of living every minute with love, grace & gratitude.</p>
    <i>Denis Waitley</i>
</div>
    <!-- denis waitley portion end -->



    <!-- team member portion start -->
<div id="tenthContainer">
    <h2>Team Members</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis, incidunt, velit accusantium libero consectetur nihil et eum voluptates veritatis perspiciatis ad maxime voluptatum consequatur dolorum.</p>
</div>
<!-- team member portion end -->



<div id="teamMembers">
    <div id="subMembers">
        <div class="profile">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"><h3>JAMES PHILLY</h3>
            <p>Lead Developer</p>
        </div>
        <div class="profile">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"><h3>CACTUS JACK</h3>
            <p>3D Model Designer</p>
        </div>
        <div class="profile">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"><h3>JACK SPARROW</h3>
            <p>Master of All Trade</p>
        </div>
        <div class="profile">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"><h3>YAGA SQIAREHEAD</h3>
            <p>Manages Money</p>
        </div>
    </div>
</div>
<!-- team member portion end -->




<!-- Fact and feature portion start -->
<div id="factsNumbers">
    <h2>Facts & Numbers</h2>
    <div id="subFacts">
        <div id="projectClient">
            <div class="facts">
                <h1>110</h1>
                <div class="underLine"></div>
                <p>successful projects</p>
            </div>
        
            <div class="facts">
                <h1>25</h1>
                <div class="underLine"></div>
                <p>awsome clients</p>
            </div>
        </div>

        <div id="openSource">
            <div class="facts">
                <h1>30</h1>
                <div class="underLine"></div>
                <p>open source plugins</p>
            </div>
            <div class="facts">
                <h1>13</h1>
                <div class="underLine"></div>
                <p>open source theme</p>
            </div>
        </div>
    </div>
    <div id="frameLine"></div>
</div>
<!-- Fact and feature portion end -->




<!-- new product portion start -->
<div class="upcomingProduct">
    <div class="subUpcoming">
        <div class="productDescription">
            <div class="newProduct">
                <h4>Travel/21st March, 2014</h4>
                <h2>A New Product Is Coming</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, pariatur sapiente sed accusamus quisquam, delectus enim placeat officiis eius, porro praesentium sit ipsum laudantium ea. Aliquid eligendi neque dignissimos? Repellendus.</p>
            </div>
        </div>
        <div class="upcomingImage">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"></div>
    </div>
</div>


<div class="upcomingProduct" id="upcoming">
    <div class="subUpcoming" id="xbox">
        <div class="upcomingImage">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"></div>
        <div class="productDescription">
            <div class="newProduct">
                <h4>Travel/21st March, 2014</h4>
                <h2>Jimmy's Nex Xbox Controller</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, pariatur sapiente sed accusamus quisquam, delectus enim placeat officiis eius, porro praesentium sit ipsum laudantium ea. Aliquid eligendi neque dignissimos? Repellendus.</p>
            </div>
        </div>
    </div>
</div>

<div class="upcomingProduct" id="upcoming_2">
    <div class="subUpcoming">
        <div class="productDescription">
            <div class="newProduct">
                <h4>Travel/21st March, 2014</h4>
                <h2>A New Product Is Coming</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, pariatur sapiente sed accusamus quisquam, delectus enim placeat officiis eius, porro praesentium sit ipsum laudantium ea. Aliquid eligendi neque dignissimos? Repellendus.</p>
            </div>
        </div>

        <div class="upcomingImage">
            <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#"></div>

    </div>
</div>
<!-- new product portion end -->



<!-- another day portion start -->
<div id="lastSliderContainer">
    <div id="lastSubContainer">
        <div id="lastSliderFrame">
            <div id="lastSubFrame">

                <div id="paradise" class="sliderCard">
                    <div class="verticalLine"></div>
                    <div id="sliderContent">
                        <h3>Another Day In Paradise</h3>
                        <p>Travel / 21st March, 2014</p>
                    </div>
                </div>


                <div id="alliens" class="sliderCard">
                    <div class="verticalLine"></div>
                    <div id="sliderContent">
                        <h3>Another Day In Paradise</h3>
                        <p>Travel / 21st March, 2014</p>
                    </div>
                </div>


                <div id="house" class="sliderCard">
                    <div class="verticalLine"></div>
                    <div id="sliderContent">
                        <h3>Another Day In Paradise</h3>
                        <p>Travel / 21st March, 2014</p>
                    </div>
                </div>


                <div id="paradise_2" class="sliderCard">
                    <div class="verticalLine"></div>
                    <div id="sliderContent">
                        <h3>Another Day In Paradise</h3>
                        <p>Travel / 21st March, 2014</p>
                    </div>
                </div>
                
            </div>
        </div>
        <img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="rightSlider"></div>
</div>
<!-- another day portion end -->




<!-- just before footer portion start -->
<div id="loveLess">
        <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="twitter"></div>
        <div><img src="<?php echo esc_url(get_template_directory_uri()."/"); ?>" alt="#" id="loveless_logo"></div>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima est inventore animi nisi ut, quasi error ea tempora at voluptatibus fuga quisquam praesentium optio dolorem soluta numquam atque eaque labore.</p>
</div>
<!-- just before footer portion end -->




<!--                 Footer Start               -->


               <?php
              // get_sidebar();
               get_footer(); 
               ?>
               